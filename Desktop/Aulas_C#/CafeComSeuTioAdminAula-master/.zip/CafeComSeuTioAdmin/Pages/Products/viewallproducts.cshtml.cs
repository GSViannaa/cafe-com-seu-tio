using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CafeComSeuTioAdmin.Pages.Products
{
    public class viewallproductsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
