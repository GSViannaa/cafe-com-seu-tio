﻿namespace CafeComSeuTioAdmin.Data.Models
{
    public class HelpTicket
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
    }
}
